<?php

namespace IPP\Student;

// External
use DOMDocument;
use IPP\Core\AbstractInterpreter;

// Internal
use IPP\Student\Exception\InvalidSourceStructureException; // return code 32


class Argument 
{
    
    private mixed $type;
    private mixed $value;

    /*
     *  Constructor
     */
    public function __construct(string $value, string $type, string $argPattern)
    {

        $this->value = $value;
        $this->type = $type;

        // Check if type is equal expected type
        if($this->type != $argPattern) {
            throw new InvalidSourceStructureException("Argument must be `$argPattern`, in code is `$type`.");
        }

    }


    /**
     *  Get type
     */
    public function getType() : string
    {

        return $this->type;

    }


    /**
     *  Get value
     */
    public function getValue() : mixed
    {

        return $this->value;

    }

}

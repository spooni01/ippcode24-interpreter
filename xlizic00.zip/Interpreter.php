<?php

namespace IPP\Student;

// External
use DOMDocument;

// Devcontainer
use IPP\Core\AbstractInterpreter;


/*
 *  Main interpreter class
 */
class Interpreter extends AbstractInterpreter
{

    private mixed $instructionNumbers = []; // Stores order numbers
    private int $positionOfInstructions = 0; // Stores position of current instruction in $instructionNumbers

    /*
     * Main function
     */
    public function execute(): int
    {
   
        $dom = $this->source->getDOMDocument(); // Get XML      
        $this->processOrderNumbers($dom); // Process order numbers

        // Loop through instructions by order number
        while ($this->positionOfInstructions < count($this->instructionNumbers)) {

            $this->positionOfInstructions += 1;

        }

        print_r($this->instructionNumbers);

        return 0;

    }


    /*
     *  Get order numbers and sort it
     */
    private function processOrderNumbers(DOMDocument $dom) : void
    {

        // Get root
        $rootNode = $dom->documentElement;
        
        // Retrieve order numbers
        foreach($rootNode->childNodes as $instr) {
            $tmpInstr = new DOMElement;
            $tmpInstr = $instr;
            if ($instr->nodeType === XML_ELEMENT_NODE) {
                array_push($this->instructionNumbers, $tmpInstr->getAttribute("order"));
            }
        }

        // Sort array to go from lowest to highest
        sort($this->instructionNumbers);

    }


}
